# Thuku Launcher — Ultimate source project

Thuku Launcher is a privacy-focused Android home-screen launcher project, built with Kotlin and Jetpack Compose. This archive contains the complete source tree and a GitHub Actions pipeline that tests and builds an installable APK.

> **Honest build status:** The workflow failure previously observed in the uploaded log occurred before Gradle ran: `android-actions/setup-android@v3` attempted to install the removed Android SDK package `tools`. This project uses `android-actions/setup-android@v4` and explicitly requests `platform-tools`, which avoids that specific failure. I cannot promise a perfect build without a successful run on GitHub's runner; the first run will verify compilation and reveal any additional source/device issues.

## Features included

### Home and app library
- Dark-first interface with a lime accent, subtle gradients, wallpaper backdrop, animated screen transitions, and compact-home option.
- Live clock/date, app search entry, pinned app row, folders, and real Android home-screen widgets.
- App library with search by app name or package, categories, hidden apps, pinned-first sorting, and long-press app actions.
- Loading states, empty states, retry button, fallback app-launch intent, and user-visible errors when an app or system action cannot be opened.

### Customization
- Accent presets, icon sizing, configurable app grid, labels, icon shapes, supported icon-pack integration, wallpaper visibility/dimming, clock styles, and animation controls.
- Export/import of launcher settings using JSON. Invalid backup files are caught and shown to the user instead of crashing the settings screen.
- Folder names and imported display values are normalized and bounded.

### Focus and quick tools
- Local focus timer with 15/25/45/60-minute presets.
- Shortcuts to supported Android internet, Bluetooth, display, sound, battery, wallpaper, and general settings panels.
- Real Android AppWidgetHost integration. Widget picker/configuration failures clean up allocated widget IDs and show a message.

### Error recovery
- App-level uncaught-exception handler writes a limited diagnostic report to private app storage and then delegates to Android's original crash handler.
- Selected recoverable errors are recorded locally. Logs are not uploaded by the app.
- Tools → Reliability lets you inspect a short log preview, export a diagnostic text file, clear it, and refresh the app list.
- Unit tests check settings-boundary validation. GitHub Actions runs tests and compiles the APK; build reports can be uploaded when a job fails.

## Project layout

- `app/src/main/java/com/thuku/launcher/MainActivity.kt` — launcher UI, navigation, app discovery, widgets, and system actions.
- `app/src/main/java/com/thuku/launcher/LauncherModel.kt` — settings model, app categorization, icon-pack integration, and settings backup/restore.
- `app/src/main/java/com/thuku/launcher/LauncherValidation.kt` — bounded settings/folder-name validation.
- `app/src/main/java/com/thuku/launcher/CrashDiagnostics.kt` — local crash and recoverable-error reports.
- `app/src/test/.../LauncherValidationTest.kt` — unit tests for validation.
- `.github/workflows/android.yml` — automatic Android build, test, artifact upload, and optional tag-based GitHub Release publishing.

## Easiest phone-only upload flow

You do **not** have to manually create folders or upload dozens of source files. Upload this archive as one ZIP file, then use Codespaces once to extract its contents into the repository. GitHub Actions cannot execute a workflow that exists only inside a ZIP, so the ZIP must be extracted and committed before the first automated build can run.

1. Download this ZIP and keep its original filename.
2. Open your `Thuku-launcher` repository on GitHub. If creating a brand-new repository, initialize it with a README so GitHub can create a Codespace.
3. Choose **Add file → Upload files**, upload only this ZIP, and commit it.
4. Open the repository's **Code → Codespaces** area and create/open a Codespace. Codespaces availability and usage limits depend on your GitHub account.
5. Open the Codespaces terminal. First make sure the current directory is the repository (usually `/workspaces/Thuku-launcher`), then run the commands below. The `ZIP` value must match the name you uploaded.

```bash
cd /workspaces/Thuku-launcher
ZIP='ThukuLauncher-Ultimate-AutoAPK-v0.2.0.zip'
unzip -o "$ZIP" -d /tmp/thuku-launcher-source
cp -a /tmp/thuku-launcher-source/. .
rm -f "$ZIP"
git add -A
git commit -m "Add Thuku Launcher source and automatic APK build"
git push origin HEAD
```

If Git reports `nothing to commit`, check the files at the repository root. They should include `settings.gradle.kts`, `build.gradle.kts`, the `app` folder, and `.github/workflows/android.yml`. If the branch has no upstream, use `git push -u origin HEAD` instead.

## Download the APK after the build

1. Open repository → **Actions**.
2. Open **Build Thuku Launcher APK**.
3. Open the latest run, and confirm the **Build, test and package APK** job succeeded.
4. Under **Artifacts**, download `ThukuLauncher-APK-<run number>` and extract that ZIP.
5. Install `ThukuLauncher-debug.apk` on your Android phone. `BUILD-INFO.txt` and `SHA256SUMS.txt` are included alongside it.

Every successful build creates a downloadable workflow artifact that expires after 30 days. Pushing a version tag such as `v0.2.1` triggers the workflow to attach the APK to a longer-lived GitHub Release after the build succeeds. If a release with that tag already exists, the workflow updates its assets.

### Important installation/signing note

The automatically produced APK is a **debug-signed test build**, not a Play Store production release. Hosted-runner debug signing keys may differ across builds. If Android reports a signature conflict while installing a later build over an older test build, uninstall the old Thuku debug build first, then install the new APK. This can erase that app's local settings. A stable production update path requires a private release keystore stored in GitHub Actions Secrets; never commit signing keys or passwords to the repository.

## Build environment

- Android Gradle Plugin 8.13.2
- Kotlin 2.3.21 with the matching Compose compiler plugin
- Gradle 8.13
- JDK 17
- Android SDK Platform 36 / Build Tools 36.0.0
- Stable Compose BOM 2026.09.00

The project does not require Android Studio to build on GitHub Actions. The workflow installs required SDK packages and caches Gradle dependencies. Android Studio can also open it as a Gradle project.

## If Actions fails

Open the failed run and find the first red step. The exact error—not deprecation warnings—is what matters. If the failure occurs during compilation, download `ThukuLauncher-build-diagnostics-<run number>` when available and share the relevant error text. If the build passes but Lint reports findings, the lint report is advisory and does not block APK creation; compilation and unit-test failures do block publishing.

## Privacy

The launcher does not request internet access in the app manifest. Settings and diagnostic reports are stored locally in the app's private storage. Android widgets are third-party components; their own behavior and permissions are controlled by Android and their providers. `QUERY_ALL_PACKAGES` is used to populate the launcher app library.
