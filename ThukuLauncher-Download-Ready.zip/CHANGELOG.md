# Changelog

## 0.2.0

- Fixed CI SDK setup to avoid the retired `tools` package that caused the previous build to fail before Gradle ran.
- Added automated unit-test, APK-build, checksum, artifact-upload, and tag-based release steps.
- Added local crash/recoverable-error diagnostics with export and clear actions.
- Added app-library loading/error states and a retry action.
- Added fallback launch/system-settings flows and visible error feedback.
- Centralized settings validation and added unit tests for invalid numeric values, icon shapes, and folder names.
- Refreshed adaptive launcher icon and bumped app version metadata.
