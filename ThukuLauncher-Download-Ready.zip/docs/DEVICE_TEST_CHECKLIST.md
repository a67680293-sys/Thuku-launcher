# Device smoke-test checklist

Run these checks on at least one Android phone after installing the APK. Emulator/device behavior can differ by manufacturer.

- [ ] Android opens the app and lets the user choose it as the Home app.
- [ ] Home clock and date render; wallpaper backdrop can be turned off.
- [ ] App Library shows a loading state, then installed launchable apps.
- [ ] Searching, category filters, pinned-first sorting, and clear-search behavior work.
- [ ] Tap opens an app; long-press offers pin/hide/folder actions.
- [ ] Hidden apps are excluded from normal browsing and can be unhidden from the Hidden filter.
- [ ] Add, configure, display, and remove a supported Android widget.
- [ ] Accent, icon shape/scale, columns, labels, and animation preferences persist after relaunch.
- [ ] Export a JSON setup backup, change a setting, and import the backup. Try an invalid file and verify the screen shows an error instead of closing.
- [ ] Focus timer can start, pause, reset by choosing a preset, and finish.
- [ ] Unsupported system panels show a fallback/toast rather than crashing.
- [ ] Tools → Reliability can export and clear a diagnostic report.
- [ ] Android's Back button and gesture navigation work from each screen and dialog.

## Report problems

Record Android version, device model, steps to reproduce, and the first meaningful error. Before sharing a local diagnostic file, inspect it and remove any private data.
