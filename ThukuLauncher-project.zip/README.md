# Thuku Launcher

A custom Android home launcher focused on strong visual customization, fast app finding, real Android widgets, and local-first settings. The repository is configured to build an installable APK automatically with GitHub Actions.

> **Status:** first development build (`0.1.0`). The project source and CI workflow are prepared, but the APK still needs its first successful GitHub Actions build and real-device testing. This is not being described as fully QA-verified yet.

## Included in this build

- Android Home app integration; choose Thuku Launcher from Android's Home-app settings.
- Installed-app discovery using Android's `LauncherApps` API, including supported user profiles.
- Search across application labels and package names.
- App-library filters for all apps, pinned apps, social, media, games, tools, and hidden apps.
- Pin/unpin and launcher-level hide/unhide from an app's long-press menu.
- Wallpaper-aware background with a dimming slider and fallback gradient.
- Custom accent palettes, compatible third-party icon-pack support, icon shape, icon scale, app-grid columns, labels, glass-like surfaces, compact layout, and motion toggles.
- Genuine Android app widgets via the system widget picker and `AppWidgetHost`.
- Quick actions that open Android's native settings panels when supported by the device.
- Focus timer with configurable 15/25/45/60-minute sessions.
- JSON export/import for settings, pinned apps, and the launcher's hidden-app list.
- No Internet permission in the launcher manifest; launcher preferences are stored locally.
- A GitHub Actions workflow builds the debug APK on pushes, pull requests, and manual runs. Tagging a commit with `v*` also creates a GitHub Release containing the APK.

## Build from GitHub Actions

1. Push these files to the `main` or `master` branch of the `Thuku-launcher` repository.
2. Open **Actions → Build Thuku Launcher APK** and check that the run succeeds.
3. Open the successful workflow run and download the `ThukuLauncher-debug-apk` artifact. On a `v*` tag, also download the APK from **Releases**.
4. Transfer the APK to the phone, install it, and choose **Thuku Launcher** in Android's default Home-app settings.

GitHub-hosted standard runners are generally free for public repositories. Usage limits and GitHub policies can change. This project does not need a paid build service.

## Development requirements

- Android SDK Platform 36 and Build Tools 36.0.0
- Compose BOM 2026.07.00 (stable Compose 1.11 line, selected to remain compatible with API 36 / AGP 8.13)
- JDK 17
- Gradle 8.13
- Android Gradle Plugin 8.13.2
- Kotlin 2.4.21 with the Compose compiler plugin

GitHub Actions provisions the required build tools automatically. No Android Studio installation is required merely to obtain a CI-built APK.

## Notes and limitations

- First build has not been run inside this sandbox because there is no network access to fetch Gradle and Maven dependencies. GitHub Actions is the authoritative build check.
- Debug APKs are for sideloading and testing, not Play Store publishing. A stable release-signing key should be configured securely before distributing updates to a wider audience; don't commit a production keystore or passwords to this public repository.
- Hidden apps are hidden only inside Thuku Launcher. This does not secure or disable an app elsewhere on the phone.
- Quick Settings panel actions and widgets vary by Android version and OEM software.
- This project uses the attached Nil Launcher APK only as a feature reference. It does not bundle or decompile its proprietary implementation, and it is not affiliated with Nil Launcher, Niagara Launcher, Smart Launcher, or Lawnchair.

## Research references

- [Lawnchair](https://github.com/LawnchairLauncher/lawnchair) — Android Launcher3 base, Pixel-style features, Material You theming, search and icon customization. Apache-2.0 according to its project documentation.
- [Neo Launcher](https://github.com/NeoApplications/Neo-Launcher) — themes, search engines, gestures, folders/categories, icon packs, custom widget, app hiding, and backups (GPLv3+).
- [KISS Launcher](https://github.com/Neamar/KISS) — search-first app finding and relevance/history (GPLv3+).
- [Niagara Launcher](https://niagaralauncher.com/niagara-pro-features/) — minimalist app list, theme system, widgets, pop-ups, and icon packs.
- [Smart Launcher features](https://www.smartlauncher.net/features) — adaptive grids, widget layouts, customization, folders and search.
- [Android app-widget documentation](https://developer.android.com/develop/ui/views/appwidgets/overview) — platform support for real app widgets.

Those projects informed the feature checklist only; their branded assets and proprietary source are not copied into Thuku Launcher.
